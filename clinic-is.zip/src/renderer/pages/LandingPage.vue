<template>
  <div>
    <login-component></login-component>
  </div>
</template>

<script>
import LoginComponent from './../components/LoginComponent/LoginComponent';

export default {
  name: 'landing-page',
  components: {
    LoginComponent,
  },
};
</script>

<style></style>
