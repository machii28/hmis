<template>
  <div>
    <apexcharts width="100%" type="bar" :options="options" :series="series"></apexcharts>
  </div>
</template>

<script src="./disease.js"></script>
<style lang="scss" src="./disease.scss"></style>